package book;

import java.util.ArrayList;

/**
 *
 * @author Faraz Ahmad
 */
public class Magazine extends Book {
    private ArrayList<String> editors;
    private int monthOfPublish;

    public ArrayList<String> getEditors() {
        return editors;
    }

    public void setEditors(ArrayList<String> editors) {
        this.editors = editors;
    }

    public int getMonthOfPublish() {
        return monthOfPublish;
    }

    public void setMonthOfPublish(int monthOfPublish) {
        this.monthOfPublish = monthOfPublish;
    }

    public String toString() {
        String x = "";
        return x;
    }
}
