package book;

import java.util.List;

public class Library {
    private List<Magazine> magazines;
    private List<TechnicalBook> technicalBook;
    private String libraryName;

    // GETTERS AND SETTERS.///////////////////////////////////////
    public String getLibraryName() {
        return libraryName;
    }

    public void setLibraryName(String libraryName) {
        this.libraryName = libraryName;
    }

    public List<Magazine> getMagazines() {
        return magazines;
    }

    public void setMagazines(List<Magazine> magazines) {
        this.magazines = magazines;
    }

    public List<TechnicalBook> getTechnicalBook() {
        return technicalBook;
    }

    public void setTechnicalBook(List<TechnicalBook> technicalBook) {
        this.technicalBook = technicalBook;
    }

    // PUBLIC METHODS.////////////////////////////////////////////
    public boolean addMagazine(Magazine b) {
        boolean flag = false;
        return flag;
    }

    public boolean deleteMagazine(String iisbn) {
        boolean flag = false;
        return flag;
    }

    public boolean addMagazine(String isbn, Magazine b) {
        boolean flag = false;
        return flag;
    }

    public List<Magazine> searchMagazineByTitle(String titleText) {
        return magazines;

    }

    public List<Magazine> searchMagazineByAuthor(String authorText) {
        return magazines;

    }

    public boolean addTechnicalBook(TechnicalBook b) {
        return false;

    }

    public boolean deleteTechnicalBook(String isbn) {
        return false;

    }

    public boolean editTechnicalBook(String isbn, TechnicalBook b) {
        return false;

    }

    public List<TechnicalBook> searchTechnicalBookByTitle(String titleText) {
        return technicalBook;

    }

    public List<TechnicalBook> searchTechnicalBookByAuthor(String authorText) {
        return technicalBook;

    }

    public void saveData() {

    }

    public void loadData() {

    }
}
