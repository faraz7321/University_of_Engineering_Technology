package book;

/**
 *
 * @author Faraz Ahmad
 */
public class Book {
    private String title;
    private String ISBN;
    private String bookStatus;

    public String getBookStatus() {
        return bookStatus;
    }

    public void setBookStatus(String bookStatus) {
        this.bookStatus = bookStatus;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String iSBN) {
        ISBN = iSBN;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

    }

}
