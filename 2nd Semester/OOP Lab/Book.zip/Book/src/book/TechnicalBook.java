package book;

import java.util.ArrayList;

/**
 *
 * @author Faraz Ahmad
 */
public class TechnicalBook extends Book {
    private ArrayList<String> authors;
    private String edition;

    public ArrayList<String> getAuthors() {
        return authors;
    }

    public void setAuthors(ArrayList<String> authors) {
        this.authors = authors;
    }

    public String getEdition() {
        return edition;
    }

    public void setEdition(String edition) {
        this.edition = edition;
    }

    public String toString() {
        String x = "";
        return x;
    }

}
