#include <iostream>
using namespace std;
int main()

{
	//i have no idea what an echelon matrix is :)

	return 0;
}
